using System;

namespace CharacterEditor
{
    enum EditingMode
    {
        None,
        FrameName,
        AnimationName,
        PathName
    }
}
