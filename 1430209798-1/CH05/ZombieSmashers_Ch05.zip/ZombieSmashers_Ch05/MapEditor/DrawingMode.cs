using System;

namespace MapEditor
{
    enum DrawingMode
    {
        SegmentSelection,
        CollisionMap,
        Ledges
    }
}
