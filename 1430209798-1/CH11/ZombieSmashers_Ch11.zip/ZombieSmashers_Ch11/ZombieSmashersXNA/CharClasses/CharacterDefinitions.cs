using System;
using System.Collections.Generic;
using System.Text;

namespace ZombieSmashers
{
    public enum CharacterDefinitions
    {
        Guy = 0,
        Zombie = 1,
        Wraith = 2,
        Carlos = 3
    }
}
