using System;
using System.Collections.Generic;
using System.Text;

namespace ZombieSmashers
{
    public enum PressedKeys
    {
        None,
        Upper,
        Lower,
        Attack,
        Secondary,
        SecUp,
        SecDown
    }
}
