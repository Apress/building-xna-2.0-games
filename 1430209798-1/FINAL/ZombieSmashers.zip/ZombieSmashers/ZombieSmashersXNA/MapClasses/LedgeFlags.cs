using System;
using System.Collections.Generic;
using System.Text;

namespace ZombieSmashers.map
{
    enum LedgeFlags
    {
        None = 0,
        Solid
    }
}
