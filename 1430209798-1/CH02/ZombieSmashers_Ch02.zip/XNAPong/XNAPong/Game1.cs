using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace XNAPong
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        private readonly GraphicsDeviceManager graphics;
        private SpriteBatch spriteBatch;

        private Texture2D spritesTexture;
        private Texture2D backgroundTexture;

        private float[] force = new float[] { 0.0f, 0.0f };
        private float[] paddleLoc = new float[] { 300f, 300f };
        private Vector2 ballLoc = new Vector2(200f, 100f);
        private Vector2 ballTraj = new Vector2();
        private bool playing = false;

        private AudioEngine engine;
        private WaveBank wave;
        private SoundBank sound;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            base.Initialize();

            engine = new AudioEngine(@"Content/sfx/sfx.xgs");
            wave = new WaveBank(engine, @"Content/sfx/snd.xwb");
            sound = new SoundBank(engine, @"Content/sfx/snd.xsb");
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            // Load the Sprite Sheet into memory using the content manager.
            // ContentManager.Load<Type>(Path without extension)
            spritesTexture = Content.Load<Texture2D>(@"gfx/sprites");

            // Load the background
            backgroundTexture = Content.Load<Texture2D>(@"gfx/background");
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            float et = (float)gameTime.ElapsedGameTime.Milliseconds;

            // TODO: Add your update logic here
            for (int i = 0; i < paddleLoc.Length; i++)
            {
                // Get the player state for each paddle.
                GamePadState state = GamePad.GetState((PlayerIndex)i);

                // Update the location using the left joystick.
                // We subtract because up on the thumbstick is positive and up
                // on the screen is negative.
                paddleLoc[i] -= state.ThumbSticks.Left.Y * et * 0.5f;

                if (force[i] > 0.0f)
                    force[i] -= et;

                float t = force[i] / 50f;
                if (t > 1.0f) t = 1.0f;
                if (t < 0.0f) t = 0.0f;

                GamePad.SetVibration((PlayerIndex)i, t, t);

                // Check against the top of the screen
                if (paddleLoc[i] < 100f) paddleLoc[i] = 100f;

                // Check against the bottom of the screen
                if (paddleLoc[i] > GraphicsDevice.Viewport.Height - 100) paddleLoc[i] = GraphicsDevice.Viewport.Height - 100;

                // If we aren't playing, check if the player wants to start the game.
                if (!playing)
                {
                    if (state.Buttons.A == ButtonState.Pressed)
                    {
                        playing = true;

                        ballLoc.X = 400f;
                        ballLoc.Y = 300f;

                        ballTraj.X = ((float)i - 0.5f) * -0.5f;
                        ballTraj.Y = ((float)i - 0.5f) * 0.5f;
                    }
                }
            }

            // If we are playing, we need to upload the ball
            if (playing)
            {
                // Save the current X location for later
                float pX = ballLoc.X;

                // Upload the position
                ballLoc += ballTraj * et;

                // Check against the boundaries of the screen.
                if (ballLoc.X > GraphicsDevice.Viewport.Width || ballLoc.X < 0f) playing = false;

                // Check against the top and bottom boundaries.
                if (ballLoc.Y < 50f)
                {
                    ballLoc.Y = 50f;
                    ballTraj.Y *= -1f;
                }
                else if (ballLoc.Y > 550f)
                {
                    ballLoc.Y = 550f;
                    ballTraj.Y *= -1f;
                }

                // Test against each paddle if necessary.
                if (ballLoc.X < 64f) TestBallCollision(0, pX >= 64f);
                if (ballLoc.X > GraphicsDevice.Viewport.Width - 64f) TestBallCollision(1, pX <= GraphicsDevice.Viewport.Width - 64f);
            }

            engine.Update();

            base.Update(gameTime);
        }

        /// <summary>
        /// Tests for collisions between a ball and a paddle.
        /// </summary>
        /// <param name="i">The paddle to test against.</param>
        /// <param name="reverse">Whether or not the ball needs to be reversed.</param>
        private void TestBallCollision(int i, bool reverse)
        {
            if (ballLoc.Y < paddleLoc[i] + 64f && ballLoc.Y > paddleLoc[i] - 64f)
            {
                if (reverse)
                    ballTraj.X *= -1f;

                ballTraj.Y = (ballLoc.Y - paddleLoc[i]) * 0.01f;

                force[i] = 100f;
                sound.PlayCue("zap");
            }
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            graphics.GraphicsDevice.Clear(Color.CornflowerBlue);

            // Start the sprite batch and be sure it allows
            // for transparency.
            spriteBatch.Begin(SpriteBlendMode.AlphaBlend);

            // Draw the background
            spriteBatch.Draw(
                backgroundTexture,
                new Rectangle(
                    0,
                    0,
                    GraphicsDevice.Viewport.Width,
                    GraphicsDevice.Viewport.Height),
                Color.White
            );
            
            // Draw the paddles.
            for (int i = 0; i < paddleLoc.Length; i++)
            {
                Rectangle destRect = new Rectangle(
                    (i * 736),
                    (int)paddleLoc[i] - 64,
                    64,
                    128
                    );

                // Draw the paddle
                spriteBatch.Draw(spritesTexture, destRect, new Rectangle(i * 64, 0, 64, 128), Color.White);
            }

            spriteBatch.Draw(
                spritesTexture,
                new Rectangle((int)ballLoc.X - 16, (int)ballLoc.Y - 16, 32, 32),
                new Rectangle(128, 0, 64, 64),
                Color.White);

            // End the sprite batch.
            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
