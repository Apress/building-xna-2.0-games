using System;
using System.Collections.Generic;
using System.Text;

namespace Generics
{
    class Program
    {
        static void Main(string[] args)
        {
            ListBase<int> myIntegers = new ListBase<int>();
            myIntegers.ItemAdded += OnItemAdded;

            myIntegers.Add(3);
        }

        static void OnItemAdded(object sender, EventArgs args)
        {
            Console.WriteLine("Item added: {0}", sender);
        }
    }
}
