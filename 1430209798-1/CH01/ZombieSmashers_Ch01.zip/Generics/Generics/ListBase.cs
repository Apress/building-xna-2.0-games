using System;
using System.Collections.Generic;

namespace Generics
{
    class ListBase<T> : List<T>
    {
        public event EventHandler ItemAdded;
        public event EventHandler ItemRemoved;

        public ListBase()
        {
            ItemAdded += OnItemAdded;
            ItemRemoved += OnItemRemoved;
        }

        ~ListBase()
        {
            ItemAdded -= OnItemAdded;
            ItemRemoved -= OnItemRemoved;
        }

        protected virtual void OnItemAdded(object sender, EventArgs e)
        {
        }

        protected virtual void OnItemRemoved(object sender, EventArgs e)
        {
        }

        public new void Add(T item)
        {
            base.Add(item);

            if (ItemAdded != null)
                ItemAdded.Invoke(item, EventArgs.Empty);
        }

        public new bool Remove(T item)
        {
            bool returnValue = base.Remove(item);

            if (ItemRemoved != null)
                ItemRemoved.Invoke(item, EventArgs.Empty);

            return returnValue;
        }
    }
}
