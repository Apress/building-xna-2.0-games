using System;
using System.Collections.Generic;
using System.Text;

namespace Chapter01
{
    class CardboardBox : Box
    {
        private int thickness;

        public int Thickness
        {
            get { return thickness; }
            set { thickness = value; }
        }
    }
}
