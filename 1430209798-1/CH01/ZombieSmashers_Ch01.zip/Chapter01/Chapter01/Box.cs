using System;
using System.Collections.Generic;
using System.Text;

namespace Chapter01
{
    class Box
    {
        private int height;
        private int width;
        private int length;

        private bool isOpened = false;
        private bool hasTop = true;

        public void Open()
        {
            if (IsOpened || !HasTop)
                return;
            else if (!IsOpened && HasTop)
                HasTop = false;

            IsOpened = true;
        }

        public bool HasTop
        {
            get { return hasTop; }
            protected set { hasTop = value; }
        }

        public bool IsOpened
        {
            get { return isOpened; }
            private set { isOpened = value; }
        }

        public int Height
        {
            get { return height; }
            set { height = value; }
        }

        public int Width
        {
            get { return width; }
            set { width = value; }
        }

        public int Length
        {
            get { return length; }
            set { length = value; }
        }
    }
}
