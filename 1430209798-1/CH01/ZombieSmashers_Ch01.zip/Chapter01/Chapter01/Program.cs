using System;
using System.Collections.Generic;
using System.Text;

namespace Chapter01
{
    class Program
    {
        static void Main(string[] args)
        {
            Box box = new Box();
            box.Width = 10;
            box.Height = 10;
            box.Length = 10;

            CardboardBox cbBox = new CardboardBox();
            cbBox.Width = 10;
            cbBox.Height = 10;
            cbBox.Length = 10;
            cbBox.Thickness = 2;

            Console.WriteLine("Box Volume: {0}", box.Width * box.Height * box.Length);
            Console.WriteLine("Cardboard Box Volume: {0}", cbBox.Width * cbBox.Height * cbBox.Length - cbBox.Thickness * 6);
        }
    }
}
