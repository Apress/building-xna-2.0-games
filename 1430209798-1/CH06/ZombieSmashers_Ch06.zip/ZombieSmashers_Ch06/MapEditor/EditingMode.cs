using System;

namespace MapEditor
{
    enum EditingMode
    {
        None,
        Path
    }
}
