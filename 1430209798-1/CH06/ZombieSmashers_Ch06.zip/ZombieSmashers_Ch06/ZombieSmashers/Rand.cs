using System;
using Microsoft.Xna.Framework;

namespace ZombieSmashers
{
    public static class Rand
    {
        private static Random random;

        public static Random Random
        {
            get { return random; }
            private set { random = value; }
        }

        static Rand()
        {
            Random = new Random();
        }

        public static float GetRandomFloat(float fMin, float fMax)
        {
            return (float)Random.NextDouble() * (fMax - fMin) + fMin;
        }

        public static double GetRandomDouble(float dMin, float dMax)
        {
            return Random.NextDouble() * (dMax - dMin) + dMin;
        }

        public static Vector2 GetRandomVector2(float xMin, float xMax, float yMin, float yMax)
        {
            return new Vector2(
                GetRandomFloat(xMin, xMax),
                GetRandomFloat(yMin, yMax)
                );
        }

        public static int GetRandomInt(int iMin, int iMax)
        {
            return Random.Next(iMin, iMax);
        }
    }
}
