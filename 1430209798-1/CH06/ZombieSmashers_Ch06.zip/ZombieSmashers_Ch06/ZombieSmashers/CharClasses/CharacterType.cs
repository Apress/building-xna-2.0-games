using System;

namespace ZombieSmashers.CharClasses
{
    public enum CharacterType
    {
        Guy = 0,
        Zombie
    }
}
