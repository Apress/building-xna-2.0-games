using System;
using System.Collections.Generic;
using System.Text;

namespace ZombieSmashers.CharClasses
{
    class Script
    {
        Character character;

        public Script(Character character)
        {
            this.character = character;
        }

        public void DoScript(int animIdx, int keyFrameIdx)
        {
            CharDef charDef = character.Definition;
            Animation animation = charDef.Animations[animIdx];
            KeyFrame keyFrame = animation.KeyFrames[keyFrameIdx];

            bool done = false;

            for (int i = 0; i < keyFrame.Scripts.Length; i++)
            {
                if (done) break;

                ScriptLine line = keyFrame.Scripts[i];

                if (line != null)
                {
                    switch (line.Command)
                    {
                        case Commands.SetAnim:
                            character.SetAnim(line.SParam);
                            break;
                        case Commands.Goto:
                            character.AnimFrame = line.IParam;
                            break;
                        case Commands.IfUpGoto:
                            if (character.KeyUp)
                            {
                                character.AnimFrame = line.IParam;
                                done = true;
                            }
                            break;
                        case Commands.IfDownGoto:
                            if (character.KeyDown)
                            {
                                character.AnimFrame = line.IParam;
                                done = true;
                            }
                            break;
                        case Commands.Float:
                            character.Floating = true;
                            break;
                        case Commands.UnFloat:
                            character.Floating = false;
                            break;
                        case Commands.Slide:
                            character.Slide(line.IParam);
                            break;
                        case Commands.Backup:
                            character.Slide(-line.IParam);
                            break;
                        case Commands.SetJump:
                            character.SetJump(line.IParam);
                            break;
                        case Commands.JoyMove:
                            if (character.KeyLeft)
                                character.Trajectory.X = -character.Speed;
                            else if (character.KeyRight)
                                character.Trajectory.X = character.Speed;
                            break;
                        case Commands.ClearKeys:
                            character.PressedKey = PressedKeys.None;
                            break;
                        case Commands.SetUpperGoto:
                            character.GotoGoal[(int)PressedKeys.Upper] = line.IParam;
                            break;
                        case Commands.SetAtkGoto:
                            character.GotoGoal[(int)PressedKeys.Attack] = line.IParam;
                            break;
                        case Commands.SetAnyGoto:
                            character.GotoGoal[(int)PressedKeys.Upper] = line.IParam;
                            character.GotoGoal[(int)PressedKeys.Lower] = line.IParam;
                            character.GotoGoal[(int)PressedKeys.Attack] = line.IParam;
                            break;
                        case Commands.SetSecondaryGoto:
                            character.GotoGoal[(int)PressedKeys.Secondary] = line.IParam;
                            character.GotoGoal[(int)PressedKeys.SecUp] = line.IParam;
                            character.GotoGoal[(int)PressedKeys.SecDown] = line.IParam;
                            break;
                        case Commands.SetSecUpGoto:
                            character.GotoGoal[(int)PressedKeys.SecUp] = line.IParam;
                            break;
                        case Commands.SetSecDownGoto:
                            character.GotoGoal[(int)PressedKeys.SecDown] = line.IParam;
                            break;
                    }
                }
            }

        }
    }
}
