using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

using ZombieSmashers.MapClasses;

namespace ZombieSmashers.CharClasses
{
    public enum CharState
    {
        Grounded = 0,
        Air = 1
    }

    public enum CharDir
    {
        Left = 0,
        Right = 1
    }

    public enum LedgeFlags
    {
        Solid = 0
    }

    class Character
    {
        public static Texture2D[] headTex = new Texture2D[1];
        public static Texture2D[] torsoTex = new Texture2D[1];
        public static Texture2D[] legsTex = new Texture2D[1];
        public static Texture2D[] weaponTex = new Texture2D[1];

        internal static void LoadTextures(ContentManager content)
        {
            for (int i = 0; i < headTex.Length; i++)
                headTex[i] = content.Load<Texture2D>(@"gfx/head" + (i + 1).ToString());

            for (int i = 0; i < torsoTex.Length; i++)
                torsoTex[i] = content.Load<Texture2D>(@"gfx/torso" + (i + 1).ToString());

            for (int i = 0; i < legsTex.Length; i++)
                legsTex[i] = content.Load<Texture2D>(@"gfx/legs" + (i + 1).ToString());

            for (int i = 0; i < weaponTex.Length; i++)
                weaponTex[i] = content.Load<Texture2D>(@"gfx/weapon" + (i + 1).ToString());
        }

        public Vector2 Location;
        public Vector2 Trajectory;
        public CharDir Face;
        public float Scale;
        public int AnimFrame;
        public CharState State;
        public int Anim;
        public string AnimName;

        public float Speed = 200f;

        public bool KeyLeft;
        public bool KeyRight;
        public bool KeyUp;
        public bool KeyDown;

        public bool KeyJump;
        public bool KeyAttack;
        public bool KeySecondary;

        public bool Floating;

        public Map Map;

        private CharDef charDef;

        private float frame = 0f;
        private int ledgeAttach = -1;

        GamePadState curState = new GamePadState();
        GamePadState prevState = new GamePadState();

        private Script script;
        public PressedKeys PressedKey;
        public int[] GotoGoal = { -1, -1, -1, -1, -1, -1, -1, -1 };

        public Character(Vector2 newLoc, CharDef newCharDef)
        {
            Location = newLoc;
            Trajectory = new Vector2();

            Face = CharDir.Right;
            Scale = 0.5f;
            charDef = newCharDef;

            SetAnim("fly");

            State = CharState.Air;

            script = new Script(this);
        }

        public void DoInput(int index)
        {
            curState = GamePad.GetState((PlayerIndex)index);

            KeyLeft = false;
            KeyRight = false;
            KeyJump = false;
            KeyUp = false;
            KeyDown = false;
            KeyAttack = false;
            KeySecondary = false;

            if (curState.ThumbSticks.Left.X < -0.1f)
                KeyLeft = true;

            if (curState.ThumbSticks.Left.X > 0.1f)
                KeyRight = true;

            if (curState.ThumbSticks.Left.Y < -0.1f)
                KeyDown = true;

            if (curState.ThumbSticks.Left.Y > 0.1f)
                KeyUp = true;

            if (curState.Buttons.A == ButtonState.Pressed &&
                prevState.Buttons.A == ButtonState.Released)
                KeyJump = true;

            if (curState.Buttons.Y == ButtonState.Pressed &&
                prevState.Buttons.Y == ButtonState.Released)
                KeyAttack = true;

            if (curState.Buttons.X == ButtonState.Pressed &&
                prevState.Buttons.X == ButtonState.Released)
                KeySecondary = true;

            prevState = curState;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            Rectangle sRect = new Rectangle();

            int frameIdx = charDef.Animations[Anim].KeyFrames[AnimFrame].FrameRef;

            Frame frame = charDef.Frames[frameIdx];

            spriteBatch.Begin(SpriteBlendMode.AlphaBlend);

            for (int i = 0; i < frame.Parts.Length; i++)
            {
                Part part = frame.Parts[i];

                if (part.Index > -1)
                {
                    sRect.X = ((part.Index % 64) % 5) * 64;
                    sRect.Y = ((part.Index % 64) / 5) * 64;
                    sRect.Width = 64;
                    sRect.Height = 64;

                    if (part.Index >= 192)
                    {
                        sRect.X = ((part.Index % 64) % 4) * 80;
                        sRect.Y = ((part.Index % 64) / 4) * 64;
                        sRect.Width = 80;
                    }

                    float rotation = part.Rotation;

                    Vector2 location = part.Location * Scale + Location - Game1.Scroll;
                    Vector2 scaling = part.Scaling * Scale;
                    if (part.Index >= 128) scaling *= 1.35f;

                    if (Face == CharDir.Left)
                    {
                        rotation = -rotation;
                        location.X -= part.Location.X * Scale * 2.0f;
                    }

                    Texture2D texture = null;

                    int t = part.Index / 64;
                    switch (t)
                    {
                        case 0:
                            texture = headTex[charDef.HeadIndex];
                            break;
                        case 1:
                            texture = torsoTex[charDef.TorsoIndex];
                            break;
                        case 2:
                            texture = legsTex[charDef.LegsIndex];
                            break;
                        case 3:
                            texture = weaponTex[charDef.WeaponIndex];
                            break;
                    }

                    Color color = Color.White;

                    bool flip = false;

                    if ((Face == CharDir.Right && part.Flip == 0) ||
                        (Face == CharDir.Left && part.Flip == 1))
                        flip = true;

                    if (texture != null)
                    {
                        spriteBatch.Draw(
                            texture,
                            location,
                            sRect,
                            color,
                            rotation,
                            new Vector2((float)sRect.Width / 2f, 32f),
                            scaling,
                            (flip ? SpriteEffects.None : SpriteEffects.FlipHorizontally),
                            1.0f
                            );
                    }
                }
            }

            spriteBatch.End();
        }

        public void Update(GameTime gameTime)
        {
            float et = (float)gameTime.ElapsedGameTime.TotalSeconds;

            #region Update Animation
            Animation animation = charDef.Animations[Anim];
            KeyFrame keyFrame = animation.KeyFrames[AnimFrame];

            frame += et * 30.0f;

            if (frame > (float)keyFrame.Duration)
            {
                int pframe = AnimFrame;

                script.DoScript(Anim, AnimFrame);

                frame -= (float)keyFrame.Duration;

                if(AnimFrame == pframe) AnimFrame++;

                if (AnimFrame >= animation.KeyFrames.Length)
                    AnimFrame = 0;

                keyFrame = animation.KeyFrames[AnimFrame];

                if (keyFrame.FrameRef < 0)
                    AnimFrame = 0;
            }
            #endregion

            #region Update Location By Trajectory
            Vector2 pLoc = new Vector2(Location.X, Location.Y);

            if (State == CharState.Grounded)
            {
                if (Trajectory.X > 0f)
                {
                    Trajectory.X -= Game1.Friction * et;
                    if (Trajectory.X < 0f) Trajectory.X = 0f;
                }

                if (Trajectory.X < 0f)
                {
                    Trajectory.X += Game1.Friction * et;
                    if (Trajectory.X > 0f) Trajectory.X = 0f;
                }
            }

            Location.X += Trajectory.X * et;

            if (State == CharState.Air)
            {
                Location.Y += Trajectory.Y * et;
                Trajectory.Y += et * Game1.Gravity;
            }
            #endregion

            #region Collision Detection
            #region Air State
            if (State == CharState.Air)
            {
                if (Trajectory.Y > 0.0f)
                {
                    #region Land On Ledge
                    for (int i = 0; i < 16; i++)
                    {
                        if (Map.Ledges[i].TotalNodes > 1)
                        {
                            int ts = Map.GetLedgeSec(i, pLoc.X);
                            int s = Map.GetLedgeSec(i, Location.X);

                            float fY = 0, tfY;

                            if (s > -1 && ts > -1)
                            {
                                tfY = Map.GetLedgeYLoc(i, s, pLoc.X);
                                fY = Map.GetLedgeYLoc(i, s, Location.X);

                                if (pLoc.Y <= tfY && Location.Y >= fY)
                                {
                                    Location.Y = fY;
                                    ledgeAttach = i;
                                    Land();
                                }
                                else
                                {
                                    if (Map.Ledges[i].Flags == (int)LedgeFlags.Solid && Location.Y > fY)
                                    {
                                        Location.Y = fY;
                                        ledgeAttach = i;
                                        Land();
                                    }
                                }
                            }
                        }
                    }
                    #endregion

                    #region Land On Col
                    if (Map.CheckCol(new Vector2(Location.X, Location.Y + 15)))
                    {
                        Location.Y = (int)((Location.Y + 15f) / 64f) * 64;
                        Land();
                    }
                    #endregion
                }
            }
            #endregion
            #region Grounded State
            else if (State == CharState.Grounded)
            {
                if (ledgeAttach > -1)
                {
                    if (Map.GetLedgeSec(ledgeAttach, Location.X) == -1)
                        FallOff();
                    else
                    {
                        Location.Y = Map.GetLedgeYLoc(ledgeAttach, Map.GetLedgeSec(ledgeAttach, Location.X), Location.X);
                    }
                }
                else
                {
                    if (!Map.CheckCol(new Vector2(Location.X, Location.Y + 15f)))
                        FallOff();
                }
            }
            #endregion
            #endregion

            #region Key Input
            if (AnimName == "idle" || AnimName == "run")
            {
                if (KeyLeft)
                {
                    SetAnim("run");
                    Trajectory.X = -200f;
                    Face = CharDir.Left;
                }
                else if (KeyRight)
                {
                    SetAnim("run");
                    Trajectory.X = 200f;
                    Face = CharDir.Right;
                }
                else
                {
                    SetAnim("idle");
                }

                if (KeyAttack)
                    SetAnim("attack");

                if (KeySecondary)
                    SetAnim("second");

                if (KeyJump)
                {
                    SetAnim("jump");
                    Trajectory.Y = -600f;
                    State = CharState.Air;
                    ledgeAttach = -1;
                    if (KeyRight) Trajectory.X = 200f;
                    if (KeyLeft) Trajectory.X = -200f;
                }
            }

            if (AnimName == "fly")
            {
                if (KeyLeft)
                {
                    Face = CharDir.Left;
                    if (Trajectory.X > -200f)
                        Trajectory.X -= 500f * et;
                }
                if (KeyRight)
                {
                    Face = CharDir.Right;
                    if (Trajectory.X < 200f)
                        Trajectory.X += 500f * et;
                }
            }

            if (KeyAttack)
            {
                PressedKey = PressedKeys.Attack;
                if (KeyUp) PressedKey = PressedKeys.Lower;
                if (KeyDown) PressedKey = PressedKeys.Upper;
            }

            if (KeySecondary)
            {
                PressedKey = PressedKeys.Secondary;
                if (KeyUp) PressedKey = PressedKeys.SecUp;
                if (KeyDown) PressedKey = PressedKeys.SecDown;
            }

            if (PressedKey != PressedKeys.None)
            {
                if (GotoGoal[(int)PressedKey] > -1)
                {
                    AnimFrame = GotoGoal[(int)PressedKey];

                    if (KeyLeft)
                        Face = CharDir.Left;
                    if (KeyRight)
                        Face = CharDir.Right;

                    PressedKey = PressedKeys.None;

                    for (int i = 0; i < GotoGoal.Length; i++)
                        GotoGoal[i] = -1;

                    frame = 0f;

                    script.DoScript(Anim, AnimFrame);
                }
            }
            #endregion
        }

        public void Slide(float distance)
        {
            Trajectory.X = (float)Face * 2f * distance - distance;
        }

        public void SetJump(float jump)
        {
            Trajectory.Y = -jump;
            State = CharState.Air;
            ledgeAttach = -1;
        }

        public void FallOff()
        {
            State = CharState.Air;
            SetAnim("fly");

            Trajectory.Y = 0f;
        }

        public void Land()
        {
            State = CharState.Grounded;
            SetAnim("land");
        }

        public void CheckXCol(Vector2 pLoc)
        {
            if (Trajectory.X > 0f)
                if (Map.CheckCol(new Vector2(Location.X + 25f, Location.Y - 15f)))
                    Location.X = pLoc.X;

            if (Trajectory.X < 0f)
                if (Map.CheckCol(new Vector2(Location.X - 25f, Location.Y - 15f)))
                    Location.X = pLoc.X;
        }

        public void SetAnim(string newAnim)
        {
            if (AnimName == newAnim)
                return;

            for (int i = 0; i < charDef.Animations.Length; i++)
            {
                if (charDef.Animations[i].Name == newAnim)
                {
                    Anim = i;
                    AnimFrame = 0;
                    frame = 0;
                    AnimName = newAnim;

                    break;
                }
            }
        }

        public CharDef Definition { get { return charDef; } }
    }
}
