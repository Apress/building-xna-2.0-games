using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace ZombieSmashers.CharClasses
{
    class KeyFrame
    {
        public int FrameRef;
        public int Duration;

        ScriptLine[] scripts;

        public KeyFrame()
        {
            FrameRef = -1;
            Duration = 0;

            scripts = new ScriptLine[4];
        }

        public ScriptLine[] Scripts
        {
            get { return scripts; }
        }
    }
}
