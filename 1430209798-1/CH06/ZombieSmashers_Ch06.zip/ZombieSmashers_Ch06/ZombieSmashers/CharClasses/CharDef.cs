using System;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace ZombieSmashers.CharClasses
{
    class CharDef
    {
        Animation[] animations;
        Frame[] frames;

        public string Path;

        public int HeadIndex;
        public int TorsoIndex;
        public int LegsIndex;
        public int WeaponIndex;

        public CharacterType CharType = CharacterType.Guy;

        public CharDef(string path)
        {
            animations = new Animation[64];
            for (int i = 0; i < animations.Length; i++)
                animations[i] = new Animation();

            frames = new Frame[512];
            for (int i = 0; i < frames.Length; i++)
                frames[i] = new Frame();

            Path = path;

            Read();
        }

        public void Read()
        {
            BinaryReader b = new
            BinaryReader(File.Open(@"data/" + Path + ".zmx",
            FileMode.Open, FileAccess.Read));

            Path = b.ReadString();
            HeadIndex = b.ReadInt32();
            TorsoIndex = b.ReadInt32();
            LegsIndex = b.ReadInt32();
            WeaponIndex = b.ReadInt32();

            for (int i = 0; i < animations.Length; i++)
            {
                animations[i].Name = b.ReadString();

                for (int j = 0; j <
                    animations[i].KeyFrames.Length; j++)
                {
                    KeyFrame keyframe = animations[i].KeyFrames[j];
                    keyframe.FrameRef = b.ReadInt32();
                    keyframe.Duration = b.ReadInt32();

                    ScriptLine[] scripts = keyframe.Scripts;
                    for (int s = 0; s < scripts.Length; s++)
                        scripts[s] = new ScriptLine(b.ReadString());
                }
            }

            for (int i = 0; i < frames.Length; i++)
            {
                frames[i].Name = b.ReadString();

                for (int j = 0; j < frames[i].Parts.Length; j++)
                {
                    Part p = frames[i].Parts[j];
                    p.Index = b.ReadInt32();
                    p.Location.X = b.ReadSingle();
                    p.Location.Y = b.ReadSingle();
                    p.Rotation = b.ReadSingle();
                    p.Scaling.X = b.ReadSingle();
                    p.Scaling.Y = b.ReadSingle();
                    p.Flip = b.ReadInt32();
                }
            }

            b.Close();

            Console.WriteLine("Loaded.");

        }

        public Animation[] Animations
        {
            get { return animations; }
        }

        public Frame[] Frames
        {
            get { return frames; }
        }
    }
}
