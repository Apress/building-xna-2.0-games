using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

using ZombieSmashers.CharClasses;
using ZombieSmashers.MapClasses;

namespace ZombieSmashers
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        private static Vector2 scroll;
        private const float friction = 1000f;
        private const float gravity = 900f;
        private static Vector2 screenSize = new Vector2();

        public static Vector2 ScreenSize
        {
            get { return screenSize; }
            set { screenSize = value; }
        }

        public static Vector2 Scroll
        {
            get { return scroll; }
            set { scroll = value; }
        }

        public static float Friction
        {
            get { return friction; }
        }

        public static float Gravity
        {
            get { return gravity; }
        }

        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        Texture2D[] mapBackTex = new Texture2D[1];

        Map map;

        Texture2D[] mapsTex = new Texture2D[1];
        Character[] character = new Character[16];
        CharDef[] charDef = new CharDef[16];

        public Game1()
        {
            screenSize.X = 800f;
            screenSize.Y = 600f;

            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            map = new Map();
            map.Path = "maps/map";
            map.Read();

            charDef[(int)CharacterType.Guy] = new CharDef("chars/guy");
            character[0] = new Character(new Vector2(100f, 100f), charDef[(int)CharacterType.Guy]);
            character[0].Map = map;

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            for (int i = 0; i < mapsTex.Length; i++)
                mapsTex[i] = Content.Load<Texture2D>(@"gfx/maps" + (i + 1).ToString());

            for (int i = 0; i < mapBackTex.Length; i++)
                mapBackTex[i] = Content.Load<Texture2D>(@"gfx/back" + (i + 1).ToString());

            Character.LoadTextures(Content);
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            // TODO: Add your update logic here
            float frameTime = (float)gameTime.ElapsedGameTime.TotalSeconds;
            if (character[0] != null)
            {
                Scroll += ((character[0].Location - new Vector2(400f, 400f)) - Scroll) * frameTime * 20f;
                
                float xLim = map.GetXLim();
                float yLim = map.GetYLim();

                if (scroll.X < 0f) scroll.X = 0f;
                else if (scroll.X > xLim) scroll.X = xLim;
                if (scroll.Y < 0f) scroll.Y = 0f;
                else if (scroll.Y > yLim) scroll.Y = yLim;

                character[0].DoInput(0);
            }

            for (int i = 0; i < character.Length; i++)
                if (character[i] != null)
                    character[i].Update(gameTime);

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            graphics.GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here
            map.Draw(spriteBatch, mapsTex, mapBackTex, 0, 2);

            character[0].Draw(spriteBatch);

            map.Draw(spriteBatch, mapsTex, mapBackTex, 2, 3);

            base.Draw(gameTime);
        }
    }
}
