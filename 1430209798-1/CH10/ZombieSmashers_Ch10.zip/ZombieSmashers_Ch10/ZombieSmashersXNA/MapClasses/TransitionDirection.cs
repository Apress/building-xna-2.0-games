using System;
using System.Collections.Generic;
using System.Text;

namespace ZombieSmashers
{
    public enum TransitionDirection : int
    {
        None = -1,
        Left = 0,
        Right = 1,
        Intro = 2
    }
}
