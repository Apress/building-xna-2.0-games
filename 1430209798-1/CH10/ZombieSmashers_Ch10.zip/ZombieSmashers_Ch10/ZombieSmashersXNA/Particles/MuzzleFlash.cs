using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Net;

namespace ZombieSmashers.Particles
{
    class MuzzleFlash : Particle
    {
        public MuzzleFlash(Vector2 loc,
            Vector2 traj,
            float size)
        {
            this.Location = loc;
            this.Trajectory = traj;
            this.size = size;
            this.rotation = Rand.GetRandomFloat(0f, 6.28f);
            this.Exists = true;
            this.frame = 0.05f;
            this.additive = true;
        }

        
        public override void Draw(SpriteBatch sprite, Texture2D spritesTex)
        {

            sprite.Draw(spritesTex, GameLocation,
                new Rectangle(64, 128, 64, 64), 
                new Color(
                new Vector4(1f, 0.8f, 0.6f, frame * 8f)
                ),
                rotation, new Vector2(32.0f, 32.0f), 
                size - frame, 
                SpriteEffects.None, 1.0f);
            
        }
    }
}
